package contact;

public class Contact {
    private static final int MAX_ID_LENGTH = 10;
    private static final int MAX_NAME_LENGTH = 10;
    private static final int PHONE_LENGTH = 10;
    private static final int MAX_ADDRESS_LENGTH = 30;

    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validateRequiredString(contactId, MAX_ID_LENGTH, "Invalid contact ID");

        this.contactId = contactId;
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        validateRequiredString(firstName, MAX_NAME_LENGTH, "Invalid first name");
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        validateRequiredString(lastName, MAX_NAME_LENGTH, "Invalid last name");
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        if (phone == null || !phone.matches("\\d{" + PHONE_LENGTH + "}")) {
            throw new IllegalArgumentException("Invalid phone number");
        }

        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        validateRequiredString(address, MAX_ADDRESS_LENGTH, "Invalid address");
        this.address = address;
    }

    private void validateRequiredString(String value, int maxLength, String errorMessage) {
        if (value == null || value.length() > maxLength) {
            throw new IllegalArgumentException(errorMessage);
        }
    }
}