package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testContactCreatedSuccessfully() {
        Contact contact = new Contact("1234567890", "John", "Smith", "1234567890", "123 Main Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testContactAllowsBoundaryLengths() {
        Contact contact = new Contact(
                "1234567890",
                "1234567890",
                "1234567890",
                "1234567890",
                "123456789012345678901234567890"
        );

        assertEquals("1234567890", contact.getContactId());
        assertEquals("1234567890", contact.getFirstName());
        assertEquals("1234567890", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123456789012345678901234567890", contact.getAddress());
    }

    @Test
    void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testContactIdCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "John", "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", null, "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testFirstNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "Johnathan11", "Smith", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", null, "1234567890", "123 Main Street");
        });
    }

    @Test
    void testLastNameCannotBeLongerThanTenCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Smithfield1", "1234567890", "123 Main Street");
        });
    }

    @Test
    void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Smith", null, "123 Main Street");
        });
    }

    @Test
    void testPhoneMustBeExactlyTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Smith", "123456789", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Smith", "12345678901", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Smith", "12345abcde", "123 Main Street");
        });
    }

    @Test
    void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Smith", "1234567890", null);
        });
    }

    @Test
    void testAddressCannotBeLongerThanThirtyCharacters() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("1", "John", "Smith", "1234567890", "1234567890123456789012345678901");
        });
    }
}