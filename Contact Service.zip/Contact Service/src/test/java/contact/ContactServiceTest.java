package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

    private ContactService service;
    private Contact contact;

    @BeforeEach
    void setUp() {
        service = new ContactService();
        contact = new Contact("1", "John", "Smith", "1234567890", "123 Main Street");
    }

    @Test
    void testAddContactSuccessfully() {
        service.addContact(contact);

        assertEquals(1, service.getContactCount());
        assertEquals("John", service.getContact("1").getFirstName());
    }

    @Test
    void testCannotAddNullContact() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(null);
        });
    }

    @Test
    void testCannotAddDuplicateContactId() {
        service.addContact(contact);

        Contact duplicate = new Contact("1", "Jane", "Doe", "0987654321", "456 Oak Street");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(duplicate);
        });
    }

    @Test
    void testDeleteContactSuccessfully() {
        service.addContact(contact);
        service.deleteContact("1");

        assertEquals(0, service.getContactCount());
    }

    @Test
    void testDeleteNonexistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("999");
        });
    }

    @Test
    void testUpdateFirstNameSuccessfully() {
        service.addContact(contact);
        service.updateFirstName("1", "Jane");

        assertEquals("Jane", service.getContact("1").getFirstName());
    }

    @Test
    void testUpdateLastNameSuccessfully() {
        service.addContact(contact);
        service.updateLastName("1", "Doe");

        assertEquals("Doe", service.getContact("1").getLastName());
    }

    @Test
    void testUpdatePhoneSuccessfully() {
        service.addContact(contact);
        service.updatePhone("1", "0987654321");

        assertEquals("0987654321", service.getContact("1").getPhone());
    }

    @Test
    void testUpdateNumberSuccessfully() {
        service.addContact(contact);
        service.updateNumber("1", "0987654321");

        assertEquals("0987654321", service.getContact("1").getPhone());
    }

    @Test
    void testUpdateAddressSuccessfully() {
        service.addContact(contact);
        service.updateAddress("1", "456 Oak Street");

        assertEquals("456 Oak Street", service.getContact("1").getAddress());
    }

    @Test
    void testUpdateNonexistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "Jane");
        });
    }

    @Test
    void testUpdateWithInvalidFirstNameThrowsException() {
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("1", "Johnathan11");
        });
    }

    @Test
    void testUpdateWithInvalidPhoneThrowsException() {
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("1", "12345");
        });
    }

    @Test
    void testUpdateWithInvalidAddressThrowsException() {
        service.addContact(contact);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAddress("1", "1234567890123456789012345678901");
        });
    }
}